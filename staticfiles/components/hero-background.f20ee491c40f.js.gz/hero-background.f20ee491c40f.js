
app.component('background-hero',{
    template:
    /* html */
    `
    <div class="background-layer"></div>
    `,
    data(){
        return {
            // This Data For Form Section
        }
    },
    methods : {
        // Methods Goes Here
    }
})