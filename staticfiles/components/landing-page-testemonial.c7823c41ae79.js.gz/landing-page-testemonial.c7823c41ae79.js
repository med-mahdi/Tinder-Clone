
app.component('landing-page-testemonial',{
    template:
    /* html */
    `
    <div class="testemonial-section">
        <div class="container">
            <li class="testemonial-card">
                <h3>Max Milner</h3>
                <p>For all the single people out there, especially introverted ones like us: do not be afraid to travel outside of your comfort zone. That’s where you’ll make a genuine connection. Tinder brought us together and for that, I am forever grateful. ❤</p>
            </li>
            <!--  -->
            <li class="testemonial-card">
                <h3>Martin Luver</h3>
                <p>For all the single people out there, especially introverted ones like us: do not be afraid to travel outside of your comfort zone. That’s where you’ll make a genuine connection. Tinder brought us together and for that, I am forever grateful. ❤</p>
            </li>
            <!--  -->
            <li class="testemonial-card">
                <h3>Antoin Junior</h3>
                <p>For all the single people out there, especially introverted ones like us: do not be afraid to travel outside of your comfort zone. That’s where you’ll make a genuine connection. Tinder brought us together and for that, I am forever grateful. ❤</p>
            </li>
        </div>
    </div>    
    `,
    data(){
        return {
            // This Data For Form Section
        }
    },
    methods : {
        // Methods Goes Here
    }
})